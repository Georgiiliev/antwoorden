/*
 * Conditionals
 *
 * Inspecteer de mousePressed() functie.
 * Er staan vier regels code:
 * - Twee die een witte, semitransparante vierkant tekenen
 * - Twee die ee zwarte, semitransparante cirkel tekenen
 * 
 * To do:
 * ------
 * Schrijf een if statement, zo dat:
 * - De eerste twee regels code (die van de cirkel) alleen uitgevoerd worden als:
 *     de som van mouseX en mouseY groter is dan 400
 * - De tweede twee regels (die van het vierkant) uitgevoerd worden in alle andere gevallen
 * 
 * Verwacht resultaat:
 * - Als je boven de diagonaal van links-onder naar rechts-boven klikt, wordt een vierkant getekend
 * - Als je onder de diagonaal van links-onder naar rechts-boven klikt, wordt een cirkel getekend
 * 
 */

 /**
  * Maak een magenta canvas
  * Vertel p5js om geen strokes te tekenen
  * en stel de rectdrawmode in 
  */
function setup(){
    createCanvas(400, 400);
    background(255, 0, 255);
    noStroke();
    rectMode(CENTER);
}

/**
 * Draw doet niets in dit programmaatje. Hij moet echter wel blijven staan.
 */
function draw(){}

/**
 * Als je boven diagonaal van links-onder naar rechts-boven klikt, verschijnt een vierkant
 * Anders verschijnt een cirkel
 */
function mousePressed(){
    if (mouseX + mouseY > 400) {
        fill(0, 128);
        circle(mouseX, mouseY, 6);
    } else {
        fill(255, 128);
        rect(mouseX, mouseY, 8, 8);
    }
}
