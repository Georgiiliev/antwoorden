/*
 * Inspecteer de draw() functie. 
 * - Er is een regel die de achterground vult
 * - en een regel die een cirkel tekent
 * 
 * 
 * To do:
 * ------
 * - Schrijf een loop die 21 keer loopt. De loop counter moet beginnen bij 0 en telkens één ophogen
 * - Zorg dat de regel die de cirkel tekent in de loop staat
 * - Laat de x- en y-positie van de cirkel beide gelijk zijn aan 20 en vermenigvuldigd met de loop counter
 * 
 * 
 * Verwacht resultaat: 
 * 21 cirkels verschijnen
 * De cirkels zijn gepositioneerd langs de diagonaal van links-boven naar rechts-onder
 */


function setup(){
    createCanvas(400, 400);
}


function draw(){
    background(255, 0, 255);
    for (i = 0; i < 21; i++) {
    
        circle(20 * i, 20 * i, 10);

    }
}

