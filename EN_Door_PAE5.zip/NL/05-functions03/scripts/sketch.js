/**
 * Functions
 * 
 * To do:
 * ------
 * Schrijf een functie die een konijn tekent.
 * Het konijn moet minstens bestaan uit:
 * - een hoofd
 * - twee oren
 * - twee ogen
 * - een neus
 *
 * De functie moet twee parameters accepteren
 * - een voor de x positie voor het te tekenen konijn
 * - een voor de y positie voor het te tekenen konijn
 * 
 * roep de functie tenminste één keer aan in de draw() functie daarbij de argumenten voor de positie meegevend.
 * 
 */


/**
 * maak het canvas aan
 */
function setup(){
    createCanvas(400, 400);
}

/**
 * vul het canvas met magenta
 * roep de functie aan die het konijn tekent
 */
function draw(){
    background(255, 0, 255);
    drawBunny(0,0);
}

function drawBunny(xPos, yPos) {
    noStroke();
    translate(xPos,yPos);
    //hoofd
    fill(255);
    circle(200, 200, 200);
    //oren
    fill(255);
    ellipse(250, 90, 40, 140);
    ellipse(150, 90, 40, 140);
    //ogen
    fill(0);
    circle(150, 180, 50);
    circle(250, 180, 50);
    // neus
    stroke(0)
    line(190, 220, 220, 190);
    line(190, 190, 220, 220);

}
