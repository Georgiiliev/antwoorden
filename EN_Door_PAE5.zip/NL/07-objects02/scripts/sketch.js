/*
 * Objects
 * 
 * To do:
 * ------
 * - Maak een object aan op basis van de volgende criteria:
 *  - een x property
 *  - een y property
 *  - een size property
 *  - een method die update heet. Deze method doet het volgende
 *      - maakt de size property gelijk aan de waarde van mouseX
 * 
 * - Laat de draw() functie:
 * - De update methode van het object aanroepen
 * - Een cirkel tekenen met de volgende eigenschappen:
 *  - de positie moet gelijk zijn aan het object zijn x en y properties
 *  - de grootte moet gelijk zijn aan het object zijn size property
 *  
 * Verwacht resultaat:
 * - Een cirkel op het scherm 
 *  - op de positie gelijk aan de x- en y properties van het object 
 *  - met een grootte die afhanleijk is van de horizontale positie van de muis
 * 
 */

var person = {
    x: 20,
    y: 20,
    size: 50,
    update: function(){
        this.size = mouseX;
    }
  };

function setup(){
    createCanvas(400, 400);
}

function draw(){
    background(255, 0, 255);
    person.update();
    circle(person.x, person.y, person.size);
}
