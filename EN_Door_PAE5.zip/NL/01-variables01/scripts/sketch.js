/**
 * Bekijk e draw functie en de regel die een cirkel tekent.
 * De cirkel wordt getekend op basis van de waarde van drie variabelen(let op de namen)
 * 
 * To do:
 * ------
 * - Definieer the drie variabelen die gebruikt worden in het tekenen van de cirkel
 * - De variabelen moeten boven de setup() functie gedefinieerd worden
 * - Hun waardes moeten zo bepaald worden dat:
 *  - De cirkel in het midden van de canvas verschijnt
 *  - De cirkel zo hoog en breed is als het canvas
 * 
 * Verwacht resultaat:
 * Een cirkel in het midden van de canvas en zo hoog en breed als het canvas
 */


var xPos = 200;
var yPos = 200;
var diameter = 400;

function setup(){
    createCanvas(400, 400);
}

function draw(){
    
    background(255, 0, 255);
    circle(xPos, yPos, diameter);
}

//function ellipse() 
//	createEllipse (350, 350, 350,350);