/**
 * Arrays
 * 
 * Inpecteer de draw() functie:
 * - Er staat een loop die door de elementen van een array loopt:
 *  - takes the values from that array
 *  - draws a rect using that value as a color
 *
 *
 * To do:
 * ------
 * - Boven de setup() functie:
 *  - Definieer/declareer de variabele die gebruikt wordt in de loop in de draw() function
 *  - Geef de variabele een lege array als waarde
 *
 * - In de functie mousePressed():
 *  - Voeg een random getal tussen 0 en 255 toe aan de array. Gebruik de random functie van p5js en een van de standaard methods van arrays voor het toevoegen van het random getal.
 *
 *
 * Verwachte resultaat:
 * - Je ziet evenveel vertikale balken als keren dat je geklikt hebt
 * - De balken (hoeveel het er ook zijn, vullen de hele breedte van het canvas
 * - Elke balk heeft zijn eigen grijze kleur
 *
 */

 colors = [];


/**
 * does initialisation. Here only creates the canvas (tabula rasa)
 */
function setup() {
    createCanvas(400, 400);
    noStroke();
}

/**
 * update the screen (executed about 60 times per second)
 */
function draw() {
    background(200, 200, 255);

    var rectWidth = width / colors.length;

    for (var i = 0; i < colors.length; i++) {
        fill(colors[i]);
        rect(i * rectWidth, 0, rectWidth, height);
    }
}

function mousePressed() {
    colors.push(Math.random(0,255));
}
