/*
 * Maak een animatie
 * 
 * Inspecteer de draw() functie, Het tekent een cirkel op een bepaalde positie.
 * 
 * To do:
 * ------
 * - Maak een variabele en geef hem de waarde 0
 * - Zorg dat de variabele gebruikt wordt om de x-positie van de cirkel te bepalen
 * - vergroot de waarde van de variabele met 1 in de draw() functie
 * 
 * Verwacht resultaat:
 * De cirkel beweegt van links naar rechts op het scherm
 * 
 */

var x = 0;
 /**
  * Create the canvas to draw on
  */
function setup(){
    createCanvas(400, 400);
}

/**
 * draw
 * 
 */
function draw(){
    background(255, 0, 255);

    circle(x, height / 2, 20);
	
	x += 1;
}
